int isFourDigit(int x);
int reverse4Digit(int x);
void addSides4Digit(int x);
int isPalindrome4Digit(int x);
